# Clara Home Care — Booking Demo

A portable, bilingual (English/Spanish) static website export of the current Clara Home Care booking demo. It preserves the boutique visual design, animation, interactive service details, three-step booking flow, future-only date picker, preferred time windows, before/after slider, gallery, FAQ, and sample reviews.

## Run locally

Requirements: Python 3 for the local static server; Node.js 18 or newer only if you want to run the optional build script. There are **no npm package dependencies**, no backend, and no installation step.

```bash
python3 -m http.server 8000
```

Open `http://localhost:8000`. On Windows, use `py -3 -m http.server 8000` if `python3` is not on PATH.

## Build

```bash
npm run build
```

This copies the static site into `dist/`. To preview that output:

```bash
npm run preview
```

The preview command uses Python 3 and serves `dist/` at port 4173. No `npm install` is required.

## Host on GitHub Pages

The exported page uses relative asset paths, so it works both at a domain root and under a repository path such as `https://USERNAME.github.io/REPOSITORY/`.

The simplest option is to put the archive contents in the repository root, then choose **Settings → Pages → Deploy from a branch → `main` → `/(root)`**. The source files can be served directly; no build is required. Alternatively, use the included Node build script and configure a GitHub Actions Pages workflow to deploy `dist/`.

The `platform/` directory preserves the original Manus-specific `app.config.ts` and route manifest for reference; GitHub Pages does not need them.

## Demo behavior and data

This is a front-end demo only. The form does not send or store personal information, create a real booking, calculate a price, or verify live availability. Calendar dates and Morning/Afternoon choices are preferences only. Reviews are explicitly illustrative samples, and the before/after pair is labeled as an example rather than a Clara customer claim.

## Fonts and external services

The original DM Serif Display and Manrope typefaces load from Google Fonts, matching the Manus preview. An internet connection is needed for those fonts; CSS fallbacks remain available. No external JavaScript service or booking backend is used.

See [`PHOTO-SOURCES.md`](PHOTO-SOURCES.md) for the image provenance note.
